#import <JavaScriptCore/JavaScriptCore.h>

void loadNFISpeechModules(JSContext* context);
JSValue* extractNFISpeechStructArgument(const char* type, NSInvocation* invocation, NSUInteger index, JSContext* context);
BOOL setNFISpeechStructReturnValue(const char* type, JSValue* value, NSInvocation* invocation);
